# Project-Digital Alarm Clock
## Table of Content:
* Features
* Description
* Objective
* Block Diagram
* Flow Chart
* Components
* Requirements
* Test Plan
* Code
* Circuit Diagram PNG
* Code Simulation PNG
* Further Development
* SWOT Analysis
* 4W's & 1H
* Output PNG
## Features:
* Displays countdown which trigerrs the buzzer alarm.
* After entering the correct password the buzzer will be deactivated.
## Description:
* This project focuses on developing an Digital clock with ATmega328 Micro-Controller , with a buzzer sound with a 10 seconds countdown, user needs to enter the correct password to deactivate the connection and to turn off the alarm.
* If the password i.e., # or *1234# is entered LCD will display Correct Pass
* If the password is not entered within time limit the buzzer will be triggered
* If the password i.e, * 1234*# is entered LCD will display Wrong Pass
## Objective:
* To make an Digital Clock circuit using ATmega328 and to implement it using SimulIde.
## Block Diagram
![](https://www.researchgate.net/publication/335200695/figure/fig2/AS:792332857262082@1565918282323/Digital-clock-internal-module-block-diagram.ppm)
## Flow Chart
![image](https://user-images.githubusercontent.com/98816218/157063670-43875a5c-3457-4a55-9265-70536e6ef07d.png)
## Components:
* ATmega328
* 16x2 LCD Display
* Buzzer
* Push Button Switch
* Bread Board or Dote Board
* 16MHZ Crystal
* Capacitor-22PF
* Resistors-10k,330-Ohms,1.5k
* Jumper Wires
* 3.7V Battery
* DS3231 RTC
* Battery Charging Module-TP4056
# Requirements
##  High Level Requirements

|  ID  |  Description  |
| ------  | ------  |
|  HLR1  |  Knowledge of ATmega328| 
|  HLR2  |  Writing the code  |
|  HLR3  |  Making the Circuit  |

### Low Level Requirements

|  ID  |  Description  |
|  ------  |  ------  |
|  LLR1  |  Knowledge of Components   |
|  LLR2  |  Adding necessary library files in AVR-GCC compiler for ATmega328|
|  LLR3  |  Implimenting circuit in Simu Ide  |

# Test Plan
# High Level Test Plan
|  Test ID  |  Description  |  Expected Input  |  Expected Output  |  Status  |
| ------  | ------  | ------ | ------ | ------ |
|  H01  |  Writing Code  |  Compiling the Code  |  No Errors  |  Implemented  |   
|  H02  |  Generating Hex FIle  |  Hex File  |  Hex File  |  Implemented  |
|  H03  |  Making the Circuit  |  Components  |  Circuit  |  Implemented  |
|  H04  |  Buzzer  |  Component  |  Buzzer sound  |  Implemented  |
|  H05  |  Input Password  |  #/*1234#  |  Correct Pass  |  Implemented  |
|  H06  |  Input Password  |  * 1234*#  |  Wrong Pass  |  Implemented  |
|  H07  |  Input Password  |  No Input  |  Count down display  |  Implemented  |

# Low Level Test Plan
|  Test ID  |  Description  |  Expected Input  |  Expected Output  |  Status  |
| ------  | ------  | ------ | ------ | ------ |
|  L01  |  Library files  |  Added Library files  |  Execution without Errors  |  Implemented  |   
|  L02  |  Countdown display  |  Run  |  Display  |  Implemented  |
|  L03  |  Circuit   |  Implementing Circuit    |  Run Circuit  |  Implemented  |

## Further Development:
* We can extend this project features by adding humidity, Air Quality display and even upgrade this into automatic light system and Visitor Counter System.
* For displaying Humidity we can use Hygrometer 
* For displaying Air Quality we can use Optical sensors, Metal Oxide Sesnor(To measure Nitrogen, Oxygen and Carbondioxide),Photo Ionization Sensor.
* For Visitor Counter we can use Ultra Sonic Sensor.
* For Automatic Light Sytem we can PIR Sensor. 
## SWOT Analysis:
* Strenghts: Count down alarm
* Weakness: If the user enters wrong password buzzer wont go off, there is no reset option. 
* Oppurtunities: Can be extended for displaying Humidity, Air Quality etc.
* Threats: No major threats
## 4W's & 1H:
* Who: Can be used by every person
* What: For calculating countdown
* When: Can be utilized when a person needs an alarm.
* Where: House, Offices
* How: By using Arduino and other components.
# Details of Componenets
## ATmega328
ATmega328 is an Advanced Virtual RISC (AVR) microcontroller. It supports 8-bit data processing. ATmega-328 has 32KB internal flash memory.ATmega328 has 1KB Electrically Erasable Programmable Read-Only Memory (EEPROM). This property shows if the electric supply supplied to the micro-controller is removed, even then it can store the data and can provide results after providing it with the electric supply. Moreover, ATmega-328 has 2KB Static Random Access Memory (SRAM). Other characteristics will be explained later. ATmega 328 has several different features which make it the most popular device in today’s market. These features consist of advanced RISC architecture, good performance, low power consumption, real timer counter having separate oscillator, 6 PWM pins, programmable Serial USART, programming lock for software security, throughput up to 20 MIPS etc.


![](https://www.theengineeringknowledge.com/wp-content/uploads/2021/01/Atmega328-pinout.jpg)


## 16x2 LCD Display
* Buzzer
* Push Button Switch
* Bread Board or Dote Board
* 16MHZ Crystal
* Capacitor-22PF
* Resistors-10k,330-Ohms,1.5k
* Jumper Wires
* 3.7V Battery
* DS3231 RTC
* Battery Charging Module-TP4056